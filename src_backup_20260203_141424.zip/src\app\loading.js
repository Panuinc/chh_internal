import Loading from "@/components/Loading";

export default function RootLoading() {
  return <Loading />;
}
