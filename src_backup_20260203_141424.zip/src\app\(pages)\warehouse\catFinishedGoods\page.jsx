"use client";

import React, { useCallback, useMemo } from "react";
import {
  useCatFinishedGoodsItems,
  extractDimensionCodes,
} from "@/app/(pages)/warehouse/_hooks/useCatFinishedGoods";
import { useMenu } from "@/hooks";
import { RFIDProvider, useRFIDContext } from "@/hooks";
import UICatFinishedGoods from "@/app/(pages)/warehouse/_components/catFinishedGoods/UICatFinishedGoods";
import { showToast } from "@/components";

function useProjectNames(items) {
  const [projectNames, setProjectNames] = React.useState(new Map());
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (!items || items.length === 0) return;

    const uniqueProjectCodes = new Set();
    items.forEach((item) => {
      const extracted = extractDimensionCodes(item.number);
      if (extracted.projectCode) {
        uniqueProjectCodes.add(extracted.projectCode);
      }
    });

    if (uniqueProjectCodes.size === 0) return;

    const fetchProjectNames = async () => {
      setLoading(true);
      try {
        const codes = Array.from(uniqueProjectCodes);
        const response = await fetch(
          `/api/warehouse/dimensionValues?codes=${codes.join(",")}&dimensionCode=PROJECT`,
        );

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.data) {
            const nameMap = new Map();
            data.data.forEach((dim) => {
              nameMap.set(dim.code, dim.displayName);
            });
            setProjectNames(nameMap);
          }
        }
      } catch (error) {
        console.error("Error fetching project names:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProjectNames();
  }, [items]);

  return { projectNames, loading };
}

function CatFinishedGoodsContent() {
  const { items, loading, refetch } = useCatFinishedGoodsItems({ limit: 500 });
  const { hasPermission } = useMenu();
  const { printBatch, isConnected, printing } = useRFIDContext();
  const { projectNames, loading: projectNamesLoading } = useProjectNames(items);

  const itemsWithProject = useMemo(() => {
    if (!items || items.length === 0) return [];

    return items.map((item) => {
      const extracted = extractDimensionCodes(item.number);
      return {
        ...item,
        projectCode: extracted.projectCode || null,
        projectName: extracted.projectCode
          ? projectNames.get(extracted.projectCode) || null
          : null,
        productCode: extracted.productCode || null,
      };
    });
  }, [items, projectNames]);

  const handlePrintWithQuantity = useCallback(
    async (item, quantity, options = {}) => {
      if (!isConnected) {
        showToast("warning", "Printer is not connected");
        return;
      }

      try {
        const result = await printBatch([item], {
          type: options.type || "thai-rfid",
          enableRFID: options.enableRFID !== false,
          quantity: quantity,
        });

        if (result?.success) {
          const totalPrinted = result.results?.[0]?.labels?.length || quantity;
          showToast(
            "success",
            `พิมพ์ ${item.number} สำเร็จ ${totalPrinted} ใบ`,
          );
        } else {
          const errorMsg = result?.results?.[0]?.error || "Unknown error";
          showToast("danger", `พิมพ์ไม่สำเร็จ: ${errorMsg}`);
        }
      } catch (err) {
        console.error("Print error:", err);
        showToast("danger", `Print failed: ${err.message}`);
      }
    },
    [printBatch, isConnected],
  );

  if (!hasPermission("warehouse.catFinishedGoods.view")) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-danger">
          You do not have permission to access this page
        </p>
      </div>
    );
  }

  return (
    <UICatFinishedGoods
      items={itemsWithProject}
      loading={loading || projectNamesLoading}
      onPrintWithQuantity={handlePrintWithQuantity}
      printerConnected={isConnected}
      printing={printing}
      onRefresh={refetch}
    />
  );
}

export default function CatFinishedGoodsPage() {
  return (
    <RFIDProvider
      config={{
        autoConnect: true,
        pollInterval: 15000,
      }}
    >
      <CatFinishedGoodsContent />
    </RFIDProvider>
  );
}
