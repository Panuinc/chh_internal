export {
  getAllSalesOrdersOnline,
  getSalesOrderOnlineById,
  GetAllUseCase,
  GetByIdUseCase,
  formatData,
  formatLines,
} from "./salesOrderOnline.service";
