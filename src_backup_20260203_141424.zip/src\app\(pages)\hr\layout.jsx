import ModuleLayout from "@/components/ModuleLayout";

export default function HrLayout({ children }) {
  return <ModuleLayout>{children}</ModuleLayout>;
}
