import ModuleLayout from "@/components/ModuleLayout";

export default function UISecurityLayout({ children }) {
  return <ModuleLayout>{children}</ModuleLayout>;
}
