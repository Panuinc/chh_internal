export {
  PrinterStatusBadge,
  PrinterControls,
  PrinterSettings,
} from "./printerConfig.jsx";

export { PRINT_TYPE_OPTIONS } from "@/lib/chainWay/config";
