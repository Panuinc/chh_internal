import ModuleLayout from "@/components/ModuleLayout";

export default function WarehouseLayout({ children }) {
  return <ModuleLayout>{children}</ModuleLayout>;
}
