import ModuleLayout from "@/components/ModuleLayout";

export default function SalesLayout({ children }) {
  return <ModuleLayout>{children}</ModuleLayout>;
}
