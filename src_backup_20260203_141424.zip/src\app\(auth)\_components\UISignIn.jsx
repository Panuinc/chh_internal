"use client";
import { Button, Input, Spinner } from "@heroui/react";
import Image from "next/image";

export default function UISignIn({
  username,
  password,
  isLoading,
  onUsernameChange,
  onPasswordChange,
  onSubmit,
}) {
  return (
    <div className="flex flex-row items-center justify-center w-full h-full gap-2">
      <div className="flex flex-col items-center justify-center w-full xl:w-[30%] h-full p-2 gap-2 xl:border-1 xl:border-default">
        <div className="flex items-end justify-center w-full h-fit p-2 gap-2 text-2xl font-black">
          Ever
          <span className="text-primary text-5xl">
            G
            <span className="relative inline-block">
              r
              <svg
                className="absolute -top-4 -right-1 w-7 h-7 text-primary"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z" />
              </svg>
            </span>
            een
          </span>
          Internal
        </div>

        <form
          onSubmit={onSubmit}
          className="flex flex-col items-center justify-center w-full p-2 gap-2"
        >
          <div className="flex items-center justify-center w-full h-fit p-2 gap-2">
            <Input
              type="text"
              label="รหัสผู้ใช้งาน"
              labelPlacement="outside"
              placeholder="Enter your username"
              color="default"
              variant="bordered"
              size="md"
              radius="md"
              isRequired
              value={username}
              onChange={(e) => onUsernameChange(e.target.value)}
              isDisabled={isLoading}
            />
          </div>

          <div className="flex items-center justify-center w-full h-fit p-2 gap-2">
            <Input
              type="password"
              label="รหัสผ่าน"
              labelPlacement="outside"
              placeholder="Enter your password"
              color="default"
              variant="bordered"
              size="md"
              radius="md"
              isRequired
              value={password}
              onChange={(e) => onPasswordChange(e.target.value)}
              isDisabled={isLoading}
            />
          </div>

          <div className="flex items-center justify-center w-full h-fit p-2 gap-2">
            <Button
              type="submit"
              color="primary"
              variant="shadow"
              size="md"
              radius="md"
              className="w-6/12 text-background"
              isLoading={isLoading}
              spinner={<Spinner size="md" color="current" />}
            >
              {isLoading ? "กำลัง เข้าสู่ระบบ ..." : "เข้าสู่ระบบ"}
            </Button>
          </div>
        </form>
      </div>

      <div className="xl:flex items-center justify-center xl:w-[70%] h-full p-2 gap-2 hidden">
        <Image src="/images/index.png" alt="logo" width={450} height={450} />
      </div>
    </div>
  );
}
