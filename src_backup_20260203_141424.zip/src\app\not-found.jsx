import UINotFound from "@/components/UINotFound";

export default function notFound() {
  return <UINotFound />;
}
