"use client";

import { Spinner } from "@heroui/react";

export default function Loading() {
  return <Spinner size="md" color="success" variant="wave" />;
}
