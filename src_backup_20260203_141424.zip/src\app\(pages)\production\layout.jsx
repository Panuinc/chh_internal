import ModuleLayout from "@/components/ModuleLayout";

export default function ProductionLayout({ children }) {
  return <ModuleLayout>{children}</ModuleLayout>;
}
