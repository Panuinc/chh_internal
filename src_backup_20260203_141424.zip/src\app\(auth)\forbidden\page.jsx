import { UIForbidden } from "@/components";

export default function forbidden() {
  return <UIForbidden />;
}
